<html>
<head><title>q2</title></head>
<body>
<?php
$a="This is string";
$b="This is string 2";
echo "First string is=$a<br/>";
echo "Second string is=$b<br/>";
echo "The difference is=";
echo strcmp($a,$b);
?>
</body>
</html>