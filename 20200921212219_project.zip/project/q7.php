<html>
<head><title>q6</title></head>
<body>
<?php
$arr=array(1,2,3,4,5,6,7,8);
$counter=count ($arr);
for ($i=0; $i<$counter; $i=$i+1)
{
if ($arr [$i] %2==0)
$arr [$i] =$arr [$i]/2;
else if ($arr [$i] %3==0)
$arr [$i] =$arr[$i]*3;
}
echo "Result: <br>";
foreach ($arr as $value)
echo $value."<br>";
?>

</body>
</html>