<html>
<head><title>q2</title></head>
<body>
<?php
function WordFreq($str){
 $one=substr_count( $str ,'Program');
$two=substr_count( $str ,'program');
$total=$one+$two;
return $total;
}
echo WordFreq("This program is about word searching program Program Program");
?>
</body>
</html>