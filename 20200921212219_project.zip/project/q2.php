<html>
<head><title>q2</title></head>
<body>
<?php
$q=150;
$p=10;
$total=$q*$p;
if($q>100){
$d=$total*0.10;
$n=$total-$d;
echo "The net amount after discount=$n";
}
else{
echo "The net amount = $total";
}
?>
</body>
</html>