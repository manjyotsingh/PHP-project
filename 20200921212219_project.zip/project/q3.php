<html>
<head><title>q2</title></head>
<body>
<?php
$a=5;
$b=10;
$c=15;
echo " The current values are A=$a,B=$b and C=$c<br/>";
if($a>$b && $a>$c)
{
echo "$a is greater";
}
else
if($b>$a && $b>$c)
{
echo "$b is greater";
}
else
echo "$c is greater";
?>
</body>
</html>