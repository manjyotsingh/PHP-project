<html>
<head><title>q6</title></head>
<body>
<?php
$arr=[
"Canada"=>[
"City1"=>"Montreal",
"City2"=>"Toronto",
],
"India"=>[
"City1"=>"Delhi",
"City2"=>"Mumbai",
],
"United States"=>[
"City1"=>"New  York",
"City2"=>"California",
]];

?>
<table border="1">
<tr>
<th>Country</th>
<th>City1</th>
<th>City2</th>
</tr>
<tr>
<?php
foreach($arr as $key=>$country)
{
echo "<tr>";
echo "<td>$key</td>";
foreach($country as $city){
echo "<td>$city</td>";
}
echo "</tr>";
}
?>

</tr>

</table>
</body>
</html>