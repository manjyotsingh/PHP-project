<html>
<head><title>Odd/Even</title></head>
<body>
<?php

$x= 24;

if($x%2==0)
echo 'The number is even';
else
echo 'The number is odd';
?>
</body>
</html>